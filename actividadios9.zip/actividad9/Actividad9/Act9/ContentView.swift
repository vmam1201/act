//
//  ContentView.swift
//  Act9
//
//  Created by Ignacio Landín on 04/04/21.
//  Copyright © 2021 Ignacio Landín. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
